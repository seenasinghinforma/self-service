export const MenuData = [
    {
        title: 'Discover',
        path: '/discover',
        cName: 'nav-links',
        
    },
    {
        title: 'Explore',
        path: '/explore',
        cName: 'nav-links',
        
    },
    {
        title: 'Integrate',
        path: '/integrate',
        cName: 'nav-links',
        
    },
    {
        title: 'Support',
        path: '/support',
        cName: 'nav-links',

    }
];